package multithreading;

public class Mythread2 implements Runnable {

	public void run() {
		for(int i=1; i<=5; i++) {
		System.out.println("FROM MyThread2");
		}
	}
}


package multithreading;

public class MyThreadMain {

	public static void main(String[] args) {
		MyThread1 myThread1 = new MyThread1();
		myThread1.start();

		Mythread2 myThread2 = new Mythread2();
		Thread thread = new Thread(myThread2);
		thread.start();

		MyThread3 myThread3 = new MyThread3();
		myThread3.start();

		MyThread4 myThread4 = new MyThread4();
		myThread4.start();
	}

}

package multithreading;

public class MyThread3 extends Thread {
   @Override
public void run() {
	System.out.println("From MyThread3");
}
	
	}

	



package multithreading;

public class MyThread4 extends Thread {
     @Override
    public void run() {
    	System.out.println("From MyThread4");
    }
	
		

	
	}


